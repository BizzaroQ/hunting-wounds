using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;



namespace HuntingWounds
{
    public class HuntingWoundsModSystem : ModSystem
    {
        public override void Start(ICoreAPI api)
        {
            base.Start(api);
            api.RegisterEntityBehaviorClass("huntingwounds", typeof(EntityBehaviorHuntingWounds));
        }
    }
}

public class EntityBehaviorHuntingWounds : EntityBehavior
{
    // TODO: Implement pheromone and blood trails
    private float speedPenaltyPerHit = -0.15f;
    private float speedBoostPerHit = 0.20f;
    private int hitCount = 0;
    private float speedModifier = 0f;
    private SimpleParticleProperties bloodParticles;
    private float particleTimer = 0f;

    public EntityBehaviorHuntingWounds(Entity entity) : base(entity)
    {
        bloodParticles = new SimpleParticleProperties(
            1, 3,
            ColorUtil.ToRgba(255, 150, 0, 0),
            new Vec3d(), new Vec3d(),
            new Vec3f(-1, 0, -1), new Vec3f(1, 1, 1),
            1.5f, 1f, 0.5f, 1.5f, EnumParticleModel.Cube
        );
    }

    private bool isHuntable = true;

    public override string PropertyName() => "huntingwounds";

    public override void Initialize(EntityProperties properties, JsonObject attributes)
    {
        base.Initialize(properties, attributes);
        hitCount = entity.WatchedAttributes.GetInt("woundHitCount", 0);
        speedModifier = entity.WatchedAttributes.GetFloat("woundSpeedModifier", 0f);
        ApplySpeedModifier();
    }

    public override void AfterInitialized(bool onFirstSpawn)
    {
        base.AfterInitialized(onFirstSpawn);
        // Ensure the entity is harvestable (drops food/resources when butchered)
        isHuntable = entity.HasBehavior("harvestable");
    }

    public override void OnEntityReceiveDamage(DamageSource damageSource, ref float damage)
    {
        base.OnEntityReceiveDamage(damageSource, ref damage);

        if (!isHuntable || entity.Api.Side != EnumAppSide.Server) return;

        if (damageSource.Type != EnumDamageType.Heal && damage > 0)
        {
            hitCount++;
            entity.WatchedAttributes.SetInt("woundHitCount", hitCount);

            // 80% chance to slow down, 20% chance for an adrenaline speed boost
            string rollType;
            if (entity.World.Rand.NextDouble() < 0.8)
            {
                speedModifier += speedPenaltyPerHit;
                rollType = $"SLOW ({speedPenaltyPerHit * 100:+0;-0}%)";
            }
            else
            {
                speedModifier += speedBoostPerHit;
                rollType = $"SPEED BOOST ({speedBoostPerHit * 100:+0;-0}%)";
            }

            // Cap penalty to prevent negative movement speed
            if (speedModifier < -0.9f) speedModifier = -0.9f;

            entity.WatchedAttributes.SetFloat("woundSpeedModifier", speedModifier);
            ApplySpeedModifier();

            if (entity.Api is ICoreServerAPI sapi)
            {
                sapi.SendMessageToGroup(
                    GlobalConstants.GeneralChatGroup,
                    $"[HuntingWounds Debug] Hit #{hitCount} on {entity.GetName()}: rolled {rollType} | Total speed modifier: {speedModifier * 100:+0;-0;0}%",
                    EnumChatType.Notification
                );
            }
        }
    }

    private void ApplySpeedModifier()
    {
        if (hitCount > 0)
        {
            entity.Stats.Set("walkspeed", "huntingwounds", speedModifier, true);
        }
    }

    public override void OnGameTick(float deltaTime)
    {
        base.OnGameTick(deltaTime);

        if (hitCount <= 0 || !entity.Alive || entity.Api.Side != EnumAppSide.Server) return;

        particleTimer += deltaTime;
        if (particleTimer > 0.5f)
        {
            particleTimer = 0f;
            bloodParticles.MinPos = entity.Pos.XYZ;
            bloodParticles.AddPos.Set(entity.SelectionBox.X2 - entity.SelectionBox.X1, 0, entity.SelectionBox.Z2 - entity.SelectionBox.Z1);
            entity.World.SpawnParticles(bloodParticles);
        }
    }
}